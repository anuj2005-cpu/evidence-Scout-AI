import { useEffect, useState } from "react";
import {
  Activity, ArrowRight, BadgeCheck, BookOpen, CheckCircle2, CircleHelp,
  Clock3, FileSearch, GitBranch, LoaderCircle, Search, ShieldCheck,
  Sparkles, TriangleAlert, XCircle
} from "lucide-react";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";

const verdictInfo = {
  "Supported": { icon: CheckCircle2, className: "supported", detail: "The model found signals consistent with support." },
  "Refuted": { icon: XCircle, className: "refuted", detail: "The model found signals consistent with contradiction." },
  "Not Enough Evidence": { icon: CircleHelp, className: "insufficient", detail: "Available model inputs may not be enough to decide." },
  "Conflicting Evidence/Cherrypicking": { icon: TriangleAlert, className: "conflicting", detail: "Signals may point in different directions." }
};

function App() {
  const [claim, setClaim] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [apiStatus, setApiStatus] = useState("checking");

  useEffect(() => {
    fetch(`${API_BASE}/api/health`)
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(data => setApiStatus(data.status === "ok" ? "online" : "offline"))
      .catch(() => setApiStatus("offline"));
  }, []);

  async function verifyClaim(event) {
    event.preventDefault();
    setError("");
    setResult(null);
    if (!claim.trim()) {
      setError("Enter a claim or headline first.");
      return;
    }
    setBusy(true);
    try {
      const response = await fetch(`${API_BASE}/api/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ claim: claim.trim() })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.detail || data.message || "The verification request failed.");
      setResult(data);
    } catch (e) {
      setError(e.message || "Could not reach the TruthGraph API. Check that the backend is running.");
    } finally {
      setBusy(false);
    }
  }

  const verdict = result?.verdict ? verdictInfo[result.verdict] : null;
  const VerdictIcon = verdict?.icon;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><GitBranch size={23} strokeWidth={2.4} /></div>
          <div><div className="brand-name">TruthGraph</div><div className="brand-caption">CLAIM INTELLIGENCE</div></div>
        </div>
        <div className="sidebar-rule" />
        <div className="nav-label">WORKSPACE</div>
        <div className="nav-item active"><ShieldCheck size={18} /> Claim verification</div>
        <div className="nav-item muted"><BookOpen size={18} /> Evidence explorer <span className="soon">LATER</span></div>
        <div className="nav-item muted"><Clock3 size={18} /> Recent checks <span className="soon">LATER</span></div>
        <div className="sidebar-bottom">
          <div className="status-card">
            <div className="status-head"><span className={`status-dot ${apiStatus}`} /> API status</div>
            <strong>{apiStatus === "online" ? "Connected" : apiStatus === "checking" ? "Checking…" : "Not connected"}</strong>
            <p>{apiStatus === "online" ? "Backend health check passed." : "Start the FastAPI server to enable verification."}</p>
          </div>
          <div className="sidebar-foot"><span className="tiny-mark">TG</span> Evidence first. Conclusions second.</div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="breadcrumb">Workspace <span>/</span> <strong>Claim verification</strong></div>
          <div className="topbar-right"><span className="mode-pill"><span className="mode-dot" /> MODEL WORKSPACE</span></div>
        </header>

        <section className="hero">
          <div className="eyebrow"><Sparkles size={14} /> YOUR FACT-CHECKING WORKSPACE</div>
          <h1>Follow the evidence.<br /><span>Understand the claim.</span></h1>
          <p className="hero-copy">Submit a statement to inspect its predicted verdict. TruthGraph is designed to make claim verification more transparent—not to replace careful source checking.</p>
        </section>

        <section className="verify-layout">
          <div className="input-panel panel">
            <div className="panel-title-row">
              <div className="section-icon"><FileSearch size={19} /></div>
              <div><h2>Analyze a claim</h2><p>Paste a statement or news headline below.</p></div>
            </div>
            <form onSubmit={verifyClaim}>
              <label htmlFor="claim">CLAIM TEXT</label>
              <textarea id="claim" value={claim} onChange={e => setClaim(e.target.value)} maxLength={3000} placeholder="Example: The government announced a new nationwide policy yesterday…" />
              <div className="input-meta"><span>{claim.length}/3,000 characters</span><button type="button" className="text-button" onClick={() => { setClaim(""); setResult(null); setError(""); }}>Clear text</button></div>
              <button className="verify-button" type="submit" disabled={busy}>
                {busy ? <><LoaderCircle className="spin" size={18} /> Analyzing claim…</> : <>Verify claim <ArrowRight size={18} /></>}
              </button>
              <div className="privacy-note"><ShieldCheck size={15} /> Your claim is sent to your configured backend for analysis.</div>
            </form>
            {error && <div className="error-box"><TriangleAlert size={18} /><div><strong>Could not verify this claim</strong><p>{error}</p></div></div>}
          </div>

          <div className="process-panel">
            <div className="mini-heading">HOW IT WORKS</div>
            <div className="process-step"><div className="step-icon"><Search size={18} /></div><div><strong>01 · Input</strong><p>A statement enters the verification pipeline.</p></div></div>
            <div className="step-line" />
            <div className="process-step"><div className="step-icon"><Activity size={18} /></div><div><strong>02 · Analyze</strong><p>The backend prepares model features and requests a prediction.</p></div></div>
            <div className="step-line" />
            <div className="process-step"><div className="step-icon"><BadgeCheck size={18} /></div><div><strong>03 · Review</strong><p>Read the predicted label and available confidence scores.</p></div></div>
            <div className="pipeline-note"><Clock3 size={16} /><span>Live web retrieval is planned for a later phase.</span></div>
          </div>
        </section>

        {result && (
          <section className="results-section">
            <div className="results-heading"><div><div className="eyebrow"><BadgeCheck size={14} /> ANALYSIS RESPONSE</div><h2>Verification result</h2></div><span className="response-tag">API RESPONSE</span></div>
            {result.status === "pipeline_not_configured" ? (
              <div className="notice-panel"><TriangleAlert size={22} /><div><h3>Model loaded, feature pipeline still needed</h3><p>{result.message}</p><p className="muted-copy">This is not a verdict. Connect the exact training-time feature-generation pipeline before predictions are enabled.</p></div></div>
            ) : (
              <>
                <div className={`verdict-card ${verdict?.className || ""}`}>
                  <div className="verdict-symbol">{VerdictIcon ? <VerdictIcon size={25} /> : <BadgeCheck size={25} />}</div>
                  <div className="verdict-main"><div className="mini-heading">PREDICTED VERDICT</div><h3>{result.verdict || "Prediction returned"}</h3><p>{verdict?.detail || "Review the model output alongside evidence."}</p></div>
                  {typeof result.confidence === "number" && <div className="confidence"><strong>{(result.confidence * 100).toFixed(1)}%</strong><span>model score</span></div>}
                </div>
                {result.scores && <div className="scores-panel panel"><h3>Class scores</h3>{Object.entries(result.scores).map(([label, score]) => <div className="score-row" key={label}><div className="score-label">{label}</div><div className="score-track"><div className="score-fill" style={{ width: `${Math.max(0, Math.min(1, Number(score))) * 100}%` }} /></div><div className="score-number">{(Number(score) * 100).toFixed(1)}%</div></div>)}</div>}
                <div className="disclaimer"><ShieldCheck size={17} /><p>Model output is a prediction, not proof. Verify the underlying sources before relying on a verdict.</p></div>
              </>
            )}
          </section>
        )}

        {!result && !error && <section className="bottom-grid">
          <div className="bottom-card"><div className="bottom-icon blue"><GitBranch size={19} /></div><div><h3>Multi-signal analysis</h3><p>Designed around polarity, temporal, source-diversity, and NLI features from your research pipeline.</p></div></div>
          <div className="bottom-card"><div className="bottom-icon violet"><BookOpen size={19} /></div><div><h3>Evidence-aware workflow</h3><p>Evidence cards will be added when the backend can return traceable evidence records.</p></div></div>
        </section>}

        <footer><span>TRUTHGRAPH · PROJECT PROTOTYPE</span><span>Predictions require evidence and context.</span></footer>
      </main>
    </div>
  );
}

export default App;
