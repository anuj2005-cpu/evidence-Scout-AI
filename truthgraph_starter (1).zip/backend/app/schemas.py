from typing import Dict, List, Optional
from pydantic import BaseModel, Field, ConfigDict

class VerifyRequest(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")
    claim: str = Field(min_length=5, max_length=3000, description="Claim text to analyze")

class EvidenceItem(BaseModel):
    text: str
    polarity: Optional[str] = None
    source_title: Optional[str] = None
    source_url: Optional[str] = None

class VerifyResponse(BaseModel):
    status: str
    claim: str
    verdict: Optional[str] = None
    confidence: Optional[float] = None
    scores: Optional[Dict[str, float]] = None
    evidence: List[EvidenceItem] = []
    message: Optional[str] = None
    model_version: Optional[str] = None
